---
tags: [1（目录）/Java技能树/Java/并发, 2（完成状态）/TODO, 锁, 线程安全]
title: synchronized锁定的到底是什么？
created: '2021-06-04T11:33:14.431Z'
modified: '2021-06-04T11:34:04.995Z'
---

# synchronized锁定的到底是什么？
