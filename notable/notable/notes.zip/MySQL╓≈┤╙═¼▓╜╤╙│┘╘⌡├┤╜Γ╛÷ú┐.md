---
tags: [1（目录）/Java技能树/数据存储/关系型/MySQL, 2（完成状态）/TODO, 主从同步, binlog, MySQL]
title: MySQL主从同步延迟怎么解决？
created: '2021-03-09T07:07:44.360Z'
modified: '2021-03-10T19:39:43.516Z'
---

# MySQL主从同步延迟怎么解决？
