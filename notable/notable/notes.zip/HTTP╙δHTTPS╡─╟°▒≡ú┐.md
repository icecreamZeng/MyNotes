---
tags: [1（目录）/Java技能树/计算机基础/计算机网络, 2（完成状态）/TODO, HTTP, HTTPS]
title: HTTP与HTTPS的区别？
created: '2021-03-09T06:25:10.236Z'
modified: '2021-03-10T19:39:22.773Z'
---

# HTTP与HTTPS的区别？
