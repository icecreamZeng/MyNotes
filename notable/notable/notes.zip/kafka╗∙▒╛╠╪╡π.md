---
tags: [1（目录）/Java技能树/开源框架/MQ, 2（完成状态）/TODO, Kafka, MQ]
title: kafka基本特点
created: '2021-03-09T06:37:34.051Z'
modified: '2021-03-10T19:39:30.660Z'
---

# kafka基本特点
