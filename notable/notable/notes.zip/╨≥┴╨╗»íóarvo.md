---
tags: [1（目录）/Java技能树/网络通信, 2（完成状态）/TODO, 序列化]
title: 序列化、arvo
created: '2021-03-09T08:53:56.528Z'
modified: '2021-03-10T19:39:02.164Z'
---

# 序列化、arvo
