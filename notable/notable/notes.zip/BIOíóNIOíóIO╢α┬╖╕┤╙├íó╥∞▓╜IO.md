---
tags: [1（目录）/Java技能树/计算机基础/IO, 2（完成状态）/TODO, 异步IO, IO, NIO]
title: BIO、NIO、IO多路复用、异步IO
created: '2021-03-09T07:03:23.344Z'
modified: '2021-03-10T19:39:07.044Z'
---

# BIO、NIO、IO多路复用、异步IO
