---
tags: [1（目录）/Java技能树/计算机基础/计算机网络, 2（完成状态）/TODO, TCP, UDP]
title: TCP 与 UDP 区别 ？
created: '2021-03-09T06:33:35.100Z'
modified: '2021-03-10T19:39:52.485Z'
---

# TCP 与 UDP 区别 ？
