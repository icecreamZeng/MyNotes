---
tags: [1（目录）/Java技能树/网络通信, 2（完成状态）/TODO, 网络通信, webservice]
title: webservice
created: '2021-03-09T08:56:14.784Z'
modified: '2021-03-10T19:39:55.669Z'
---

# webservice

